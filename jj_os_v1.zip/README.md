# J&J OS V1 Prototype

Open `index.html` in a browser.

This is the first functional UI prototype for the AI-native service-business operating system:
- Dashboard / AI Business Brain
- CRM
- Jobs + field workflow
- Schedule/dispatch
- Estimates + calculator
- Invoices
- Employees + roles
- Marketing
- Bookkeeping / QuickBooks connection placeholder
- Business configuration

All data is mock/client-side state. No real authentication, database, payments, QuickBooks, Meta, SMS, or AI API is connected yet.
